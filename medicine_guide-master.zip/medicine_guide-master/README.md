# medicine_guide
This is a complete medicine inventory management system.
